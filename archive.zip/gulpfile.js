var gulp = require('gulp');
var tsc = require('gulp-tsc');
var zip = require('gulp-zip');
var bintray = require('./lib/index.js');
var clean = require('gulp-clean');

var paths = {
	src: 'src/**/*.ts',
	dest: 'lib/'
};
 
var tscopts = {
	out: 'index.js',
	module: 'commonjs',
	declaration: true,
	sourcemap: true
};

var bintrayopts = {
	username: 'frankwallis',
	apikey: 'd972276f8c840c61b775331844c73166fad9dd27',
	repository: 'gulp-plugins',
	pkg: {
		name: 'gulp-bintray',
	}
}

gulp.task('compile', function() {
    gulp.src(paths.src)
        .pipe(tsc(tscopts, this))
        .pipe(gulp.dest(paths.dest));
});
 
gulp.task('bintray', function() {
    return gulp.src([ '**/*.*', '!node_modules/**' ])
        .pipe(bintray(bintrayopts))
        //.pipe(gulp.dest('./dist/'));
});

gulp.task('zip', function() {
    return gulp.src([ '**/*.*', '!node_modules/**' ])
        .pipe(zip('archive.zip'))	
        .pipe(gulp.dest('.'))
        .pipe(bintray(bintrayopts))
        .pipe(clean())
});

gulp.task('release', ['zip' ], function() {
    //return gulp.src([ '**/*.*', '!node_modules/**' ])
      //  .pipe(bintray(bintrayopts))	
        //.pipe(gulp.dest('./dist/'));
});

gulp.task('default', [ 'compile' ]);
