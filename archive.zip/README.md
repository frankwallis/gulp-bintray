gulp-bintray
============

gulp task to upload to bintray
